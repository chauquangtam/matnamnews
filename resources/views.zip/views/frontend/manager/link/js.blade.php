 <!-- ==== jQuery Library ==== -->
 <script src="frontend/js/jquery-3.2.1.min.js"></script>

 <!-- ==== Bootstrap Framework ==== -->
 <script src="frontend/js/bootstrap.min.js"></script>

 <!-- ==== StickyJS Plugin ==== -->
 <script src="frontend/js/jquery.sticky.min.js"></script>

 <!-- ==== HoverIntent Plugin ==== -->
 <script src="frontend/js/jquery.hoverIntent.min.js"></script>

 <!-- ==== Marquee Plugin ==== -->
 <script src="frontend/js/jquery.marquee.min.js"></script>

 <!-- ==== Validation Plugin ==== -->
 <script src="frontend/js/jquery.validate.min.js"></script>

 <!-- ==== Isotope Plugin ==== -->
 <script src="frontend/js/isotope.min.js"></script>

 <!-- ==== Resize Sensor Plugin ==== -->
 <script src="frontend/js/resizesensor.min.js"></script>

 <!-- ==== Sticky Sidebar Plugin ==== -->
 <script src="frontend/js/theia-sticky-sidebar.min.js"></script>

 <!-- ==== Zoom Plugin ==== -->
 <script src="frontend/js/jquery.zoom.min.js"></script>

 <!-- ==== Bar Rating Plugin ==== -->
 <script src="frontend/js/jquery.barrating.min.js"></script>

 <!-- ==== Countdown Plugin ==== -->
 <script src="frontend/js/jquery.countdown.min.js"></script>

 <!-- ==== RetinaJS Plugin ==== -->
 <script src="frontend/js/retina.min.js"></script>

 <!-- ==== Google Map API ==== -->
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBK9f7sXWmqQ1E-ufRXV3VpXOn_ifKsDuc"></script>

 <!-- ==== Main JavaScript ==== -->
 <script src="frontend/js/main.js"></script>
 @yield('jsfrontend')