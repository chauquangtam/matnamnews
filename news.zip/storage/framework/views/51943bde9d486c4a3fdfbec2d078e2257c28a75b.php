  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2022 <a href="https://www.youtube.com/channel/UCk_4ejyNxyfNcyHFJu94Zug/featured">While Key</a>.</strong>
  
  
  </footer><?php /**PATH G:\PHP\host\upload\news\news\resources\views/backend/manager/footer.blade.php ENDPATH**/ ?>