[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH G:\PHP\host\upload\news\news\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>