 <!-- ==== jQuery Library ==== -->
 <script src="<?php echo e(asset('frontend/js/jquery-3.2.1.min.js')); ?>"></script>

 <!-- ==== Bootstrap Framework ==== -->
 <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>

 <!-- ==== StickyJS Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/jquery.sticky.min.js')); ?>"></script>

 <!-- ==== HoverIntent Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/jquery.hoverIntent.min.js')); ?>"></script>

 <!-- ==== Marquee Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/jquery.marquee.min.js')); ?>"></script>

 <!-- ==== Validation Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/jquery.validate.min.js')); ?>"></script>

 <!-- ==== Isotope Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/isotope.min.js')); ?>"></script>

 <!-- ==== Resize Sensor Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/resizesensor.min.js')); ?>"></script>

 <!-- ==== Sticky Sidebar Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/theia-sticky-sidebar.min.js')); ?>"></script>

 <!-- ==== Zoom Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/jquery.zoom.min.js')); ?>"></script>

 <!-- ==== Bar Rating Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/jquery.barrating.min.js')); ?>"></script>

 <!-- ==== Countdown Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/jquery.countdown.min.js')); ?>"></script>

 <!-- ==== RetinaJS Plugin ==== -->
 <script src="<?php echo e(asset('frontend/js/retina.min.js')); ?>"></script>

 <!-- ==== Google Map API ==== -->
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBK9f7sXWmqQ1E-ufRXV3VpXOn_ifKsDuc"></script>

 <!-- ==== Main JavaScript ==== -->
 <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
 <?php echo $__env->yieldContent('jsfrontend'); ?><?php /**PATH G:\PHP\host\upload\news\news\resources\views/frontend/manager/link/js.blade.php ENDPATH**/ ?>