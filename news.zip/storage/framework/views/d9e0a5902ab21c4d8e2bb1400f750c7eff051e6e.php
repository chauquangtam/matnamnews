
<?php $__env->startSection('title'); ?>
    <title>Kcnew - Sửa thông tin người dùng</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Sửa thông tin người dùng</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Người dùng</a></li>
                        <li class="breadcrumb-item active">Sửa thông tin người dùng</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-info alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h5><i class="icon fas fa-info"></i><?php echo e(Session::get('success')); ?></h5>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-warning alert-dismissible">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Sửa thông tin người dùng</h3>
                </div>

                <!-- /.card-header -->
                <!-- form start -->
                <form  action="<?php echo e(route('user.update',['user'=>$user->id])); ?>" method="post" enctype="multipart/form-data">
                  <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    
                    <div class="card-body">
                        <div class="form-group">
                            <label>Họ và tên</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" placeholder="Nhập họ và tên">
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col">
                                    <label for="exampleInputPassword1">Email</label>
                                    <input type="email" class="form-control" value="<?php echo e($user->email); ?>" name="email" placeholder="Nhập email">
                                </div>

                                <!-- <input type="hidden" value="12345678" name="password"> -->
                                <div class="col">
                                    <label for="exampleInputPassword1">Mật khẩu</label>
                                    <input type="password" class="form-control" value="<?php echo e($user->password); ?>" name="password"
                                        placeholder="Nhập mật khẩu">
                                </div>
                                <div class="col">
                                    <label for="exampleInputPassword1">Số điện thoại</label>
                                    <input type="number" class="form-control" value="<?php echo e($user->sodienthoai); ?>" name="sodienthoai"
                                        placeholder="Nhập số điện thoại">
                                </div>
                            </div>

                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col">
                                    <label for="examleInput">Vai trò</label>
                                    <select name="role_select" id="" class="form-control">
                                        <option value="0" selected>-- Chọn vai trò -- </option>
                                        <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($u->id); ?>" ><?php echo e($u->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                               
                            </div>

                        </div>


                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                        <button type="submit" name="submit" class="btn btn-primary">Cập nhật</button>
                    </div>
                </form>

            </div>
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Thêm vai trò mới</h3>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <form action="<?php echo e(route('themvaitro')); ?>" id="formvaitro" class="formvaitro" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Thêm vai trò mới</label>
                                    <input type="text" class="form-control" name="role" placeholder="Thêm vai trò mới"
                                        id="role">

                                    <button type='submit' class="btn btn-primary vaitro" id="vaitro">Thêm</button>

                                </div>
                            </form>
                        </div>
                        

                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PHP\host\upload\news\news\resources\views/backend/pages/user/edit.blade.php ENDPATH**/ ?>