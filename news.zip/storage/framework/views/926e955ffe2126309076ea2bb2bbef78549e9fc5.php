
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <?php echo $__env->yieldContent('title'); ?>
  
    <?php echo $__env->make('backend.manager.link.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head><?php /**PATH G:\PHP\host\upload\news\news\resources\views/backend/manager/header.blade.php ENDPATH**/ ?>