<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="INDEX,FOLLOW" />
    <!-- ==== Document Title ==== -->
    <link rel="canonical"  href="<?php echo e(url()->current()); ?>"/>
    <?php echo $__env->yieldContent('title'); ?>
    <meta property="og:locale" content="vi_VN" />
    <meta property="og:type" content="article" />
    <meta property="og:site_name" content="matnamvn.com" />
    <meta property="og:url" content="<?php echo e(url()->current()); ?>" />
    <?php echo $__env->make('frontend.manager.link.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head><?php /**PATH G:\PHP\host\upload\news\news\resources\views/frontend/manager/header.blade.php ENDPATH**/ ?>