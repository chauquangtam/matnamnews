<?php echo e($slot); ?>

<?php /**PATH G:\PHP\host\upload\news\news\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>