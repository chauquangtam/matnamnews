<?php
return [
    'welcome' => 'Chào mừng bạn đến với Website!',
];