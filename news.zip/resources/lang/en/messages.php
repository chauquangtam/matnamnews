<?php
return [
    'welcome' => 'Welcome to Website!',
];
