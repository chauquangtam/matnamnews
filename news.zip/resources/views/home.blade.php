@extends('layouts.app')
@section('title')
    <title>Trang quản trị</title>
@endsection

